var searchData=
[
  ['os_5finregs',['os_InRegs',['../cmsis__os_8h.html#ac6b67612d20f480bef2d76bb64e95be8',1,'cmsis_os.h']]],
  ['oscmsis_5frtx',['osCMSIS_RTX',['../cmsis__os_8h.html#a4f74ed918c795e909dc1cea0040fd3b7',1,'cmsis_os.h']]],
  ['oswaitforever',['osWaitForever',['../cmsis__os_8h.html#a9eb9a7a797a42e4b55eb171ecc609ddb',1,'cmsis_os.h']]]
];
