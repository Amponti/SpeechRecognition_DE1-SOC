var searchData=
[
  ['mail_5fid',['mail_id',['../group___c_m_s_i_s___r_t_o_s___definitions.html#ac86175a4b1706bee596f3018322df26e',1,'osEvent']]],
  ['message_5fid',['message_id',['../group___c_m_s_i_s___r_t_o_s___definitions.html#af394cbe21dde7377974e63af38cd87b0',1,'osEvent']]],
  ['mutex',['mutex',['../structos_mutex_def__t.html#aef475bb63aad7508c7dffe80ad332e4e',1,'osMutexDef_t']]]
];
